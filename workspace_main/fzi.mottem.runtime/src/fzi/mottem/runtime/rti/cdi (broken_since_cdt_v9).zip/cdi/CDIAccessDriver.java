package fzi.mottem.runtime.rti.cdi;

import java.io.IOException;

import org.eclipse.cdt.core.model.CModelException;
import org.eclipse.cdt.core.model.CoreModel;
import org.eclipse.cdt.core.model.ICProject;
import org.eclipse.cdt.debug.core.cdi.CDIException;
import org.eclipse.cdt.debug.core.cdi.ICDIFunctionLocation;
import org.eclipse.cdt.debug.core.cdi.ICDISession;
import org.eclipse.cdt.debug.core.cdi.model.ICDIBreakpoint;
import org.eclipse.cdt.debug.core.cdi.model.ICDIBreakpointManagement2;
import org.eclipse.cdt.debug.core.cdi.model.ICDIFunctionBreakpoint;
import org.eclipse.cdt.debug.core.cdi.model.ICDITarget;
import org.eclipse.cdt.debug.core.model.ICBreakpointType;
import org.eclipse.cdt.debug.mi.core.MIException;
import org.eclipse.cdt.debug.mi.core.cdi.event.ChangedEvent;
import org.eclipse.cdt.debug.mi.core.cdi.event.DestroyedEvent;
import org.eclipse.cdt.debug.mi.core.cdi.event.ResumedEvent;
import org.eclipse.cdt.debug.mi.core.cdi.event.SuspendedEvent;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;

import fzi.mottem.model.baseelements.IExecutor;
import fzi.mottem.model.baseelements.IInspectable;
import fzi.mottem.model.baseelements.IInspector;
import fzi.mottem.model.baseelements.ISymbolContainer;
import fzi.mottem.model.baseelements.ITestCallable;
import fzi.mottem.model.baseelements.ITestReadable;
import fzi.mottem.model.baseelements.ITestReferenceable;
import fzi.mottem.model.baseelements.ITestWriteable;
import fzi.mottem.model.codemodel.CodeInstance;
import fzi.mottem.model.codemodel.Function;
import fzi.mottem.model.testrigmodel.Processor;
import fzi.mottem.model.testrigmodel.ProcessorCore;
import fzi.mottem.runtime.EItemProperty;
import fzi.mottem.runtime.interfaces.IRuntime;
import fzi.mottem.runtime.rti.AbstractAccessDriver;
import fzi.mottem.runtime.rti.cdi.CDIEventListener.Execution;

public class CDIAccessDriver extends AbstractAccessDriver
{
	private final ICProject _cproject;
	private final CDIEventListener _cdiListener = new CDIEventListener();
	
	private ICDISession _cdiSession = null;
	
	public CDIAccessDriver(IRuntime runtime, IInspector inspector)
	{
		super(runtime, inspector);
		
		IInspectable inspectedElement = inspector.getInspectorConnector().getInspectable();
		
		if (!(inspectedElement instanceof Processor))
		{
			throw new RuntimeException("Cannot construct CDIInspector: connected inspectable is no processor");
		}

		Processor processor = (Processor)inspectedElement;
		
		String cProjectName = null;
		for (ProcessorCore core : processor.getProcessorCores())
		{
			ISymbolContainer container = core.getSymbolContainer();

			if (!(container instanceof CodeInstance))
			{
				System.err.println("Omitting symbol container for CDIInspector!");
				continue;
			}
			
			String cProjectName2 = ((CodeInstance)container).getCProjectName();
			if (cProjectName == null)
			{
				cProjectName = cProjectName2;
			}
			else if (!cProjectName.equals(cProjectName2))
			{
				throw new RuntimeException("Cannot construct CDIInspector: connected inspectable refers to multiple C/C++ projects");
			}
		}

		if (cProjectName == null)
		{
			throw new RuntimeException("Cannot construct CDIInspector: connected inspectable does not refer to a C/C++ project");
		}
		
		IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(cProjectName);
		_cproject = CoreModel.getDefault().create(project);
	}

	@Override
	public void init()
	{
		try
		{
			_cdiSession = CDISessionFactory.createSession(_cproject);
			_cdiSession.getEventManager().addEventListener(_cdiListener);
		}
		catch (CModelException | IOException | MIException e)
		{
			throw new RuntimeException("Could not create and initialize CDI session", e);
		}
	}

	@Override
	public void cleanup()
	{
		if (_cdiSession == null)
			return;
		
		ICDITarget target = getTarget();

		try
		{
			if (!target.isTerminated())
			{
				target.getProcess().destroy();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				_cdiSession.terminate();
			}
			catch (CDIException e)
			{
				// Any exceptions caught here are silently
				// ignored as we are shutting down anyway.
				// Exceptions might occur because targets
				// of the session might have been terminated
				// already etc.
				// e.printStackTrace();
			}
			finally
			{
				_cdiSession = null;
			}
		}
	}

	@Override
	public <T> T getValue(ITestReadable element)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> void setValue(ITestWriteable element, T value)
	{
		// TODO Auto-generated method stub
	}

	@Override
	public <T> T getItemPropertyValue(ITestReferenceable element, EItemProperty property)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> void setItemPropertyValue(ITestReferenceable element, EItemProperty property, T value)
	{
		// TODO Auto-generated method stub
	}

	@Override
	public <T> T execute(IExecutor executor, ITestCallable executableElement, Object... arguments)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void run(IExecutor executor)
	{
		final ICDITarget target = getTarget();
		
		try
		{
			if (target.isSuspended())
			{
				_cdiListener.executeAndAwait(new Execution()
					{
						public void execute() throws CDIException { target.resume(false); }
					}, ResumedEvent.class, target);
			}
			else if (target.isDisconnected())
			{
				_cdiListener.executeAndAwait(new Execution()
					{
						public void execute() throws CDIException { target.restart(); } 
					}, ResumedEvent.class, target);
			}
			else
			{
				System.err.println("Resuming / Starting a not-suspended target!");
			}

			_cdiListener.executeAndAwait(null, SuspendedEvent.class, target);
		}
		catch (CDIException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		
	}

	@Override
	public void runUntil(IExecutor executor, ITestCallable executableElement)
	{
		final ICDITarget target = getTarget();
		
		final Function func = (Function)executableElement;
		final String fileName = func.getDeclarationLocation().getSourceFile().getFilePath();
		final ICDIFunctionLocation location = target.createFunctionLocation(fileName, func.getName());
		
		try
		{
			
			final ICDIFunctionBreakpoint bp = ((ICDIBreakpointManagement2)target).setFunctionBreakpoint(ICBreakpointType.REGULAR, location, null, false, false);
			
			_cdiListener.executeAndAwait(new Execution()
				{
					public void execute() throws CDIException { bp.setEnabled(true); } 
				}, ChangedEvent.class, bp);

			if (target.isSuspended())
			{
				_cdiListener.executeAndAwait(new Execution()
					{
						public void execute() throws CDIException { target.resume(false); }
					}, ResumedEvent.class, target);
			}
			else if (target.isDisconnected())
			{
				_cdiListener.executeAndAwait(new Execution()
					{
						public void execute() throws CDIException { target.restart(); } 
					}, ResumedEvent.class, target);
			}
			else
			{
				System.err.println("Resuming / Starting a not-suspended target!");
			}
			
			_cdiListener.executeAndAwait(null, SuspendedEvent.class, target);

			_cdiListener.executeAndAwait(new Execution()
				{
					public void execute() throws CDIException { target.deleteBreakpoints(new ICDIBreakpoint[] { bp }); } 
				}, DestroyedEvent.class, bp);
		}
		catch (CDIException e)
		{
			throw new RuntimeException(e);
		}
	}

	@Override
	public void stop(IExecutor executor)
	{
		// TODO Auto-generated method stub
	}
	
	@Override
	public void breakAt(IExecutor executor, ITestCallable executableElement)
	{
		// TODO Auto-generated method stub
	}

	private ICDITarget getTarget()
	{
		if (_cdiSession.getTargets().length != 1)
		{
			throw new RuntimeException("CDIInspector requires exactly one target");
		}

		return _cdiSession.getTargets()[0];
	}

}
