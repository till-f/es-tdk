package fzi.mottem.runtime.rti.cdi;

import java.io.File;
import java.io.IOException;

import org.eclipse.cdt.core.model.CModelException;
import org.eclipse.cdt.core.model.IBinary;
import org.eclipse.cdt.core.model.ICProject;
import org.eclipse.cdt.debug.core.cdi.ICDISession;
import org.eclipse.cdt.debug.mi.core.MIException;
import org.eclipse.cdt.debug.mi.core.MIPlugin;
import org.eclipse.cdt.debug.mi.core.MISession;
import org.eclipse.cdt.debug.mi.core.cdi.Session;
import org.eclipse.cdt.debug.mi.core.command.CommandFactory;
import org.eclipse.cdt.debug.mi.core.command.MIVersion;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Platform;

public class CDISessionFactory
{
	public static ICDISession createSession(ICProject project) throws IOException, MIException, CModelException
	{
		String workspacePath = Platform.getLocation().toOSString();
		MIPlugin mi = MIPlugin.getDefault();
		
		try
		{
			project.getProject().refreshLocal(IResource.DEPTH_INFINITE, null);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		IBinary bins[] = project.getBinaryContainer().getBinaries();
		
		if (bins.length != 1)
			throw new RuntimeException("Cannot create CDI session, referenced project must contain exactly one binary");

		String programExecFile = workspacePath + bins[0].getPath().toOSString();
		CommandFactory gdbCommandFactory = new CommandFactory(MIVersion.MI1);
		
		Session session = mi.createSession(
				MISession.PROGRAM,
				null,
				gdbCommandFactory,
				new File(programExecFile),
				new String[] { "--tty=C:\\Users\\tfischer\\gdbappoutput.txt" },
				false,
				null);
		
		return session;
	}
}
