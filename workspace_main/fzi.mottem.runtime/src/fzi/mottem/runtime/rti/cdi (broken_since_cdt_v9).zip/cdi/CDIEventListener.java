package fzi.mottem.runtime.rti.cdi;

import java.util.Hashtable;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.eclipse.cdt.debug.core.cdi.CDIException;
import org.eclipse.cdt.debug.core.cdi.event.ICDIEvent;
import org.eclipse.cdt.debug.core.cdi.event.ICDIEventListener;
import org.eclipse.cdt.debug.core.cdi.model.ICDIObject;

import fzi.mottem.runtime.util.ExecutionInterruptedException;

public class CDIEventListener implements ICDIEventListener
{
	public interface Execution
	{
		public void execute() throws CDIException;
	}

	private final Lock _lock = new ReentrantLock();
	
	private final EventManager _eventManager = new EventManager();
	
	@Override
	public void handleDebugEvents(ICDIEvent[] events)
	{
		_lock.lock();
		
		try
		{
			for (ICDIEvent event : events)
			{
				_eventManager.eventOccured(event.getClass(), event.getSource());
			}
		}
		finally
		{
			_lock.unlock();
		}
	}
	
	public void executeAndAwait(Execution execution, Class<?> event, ICDIObject source) throws CDIException
	{
		_lock.lock();
		
		try
		{
			if (execution != null)
				execution.execute();
			
			_eventManager.awaitEvent(event, source, _lock);
		}
		finally
		{
			_lock.unlock();
		}
		
	}
	
	private class EventManager
	{
		/*
		 * The internal storage of conditions being wated for.
		 */
		private final Hashtable<Integer, Condition> _conditions = new Hashtable<Integer, Condition>();
		
		/*
		 * Signals all threads waiting for the condition and removes the condition
		 * from the internal storage of conditions being waited for.
		 */
		public void eventOccured(Class<?> event, ICDIObject source)
		{
			Condition condition = findCondition(event, source);

			if (condition != null)
			{
				removeCondition(event, source);
				condition.signalAll();
			}
		}
		
		/*
		 * Looks into the internal storage of conditions being waited for and adds a new
		 * condition if no other thread is waiting for this condition. Then blocks awaiting
		 * the just created or already existing condition.
		 */
		public void awaitEvent(Class<?> event, ICDIObject source, Lock conditionFactory)
		{
			Condition condition = findCondition(event, source);
			
			if (condition == null)
			{
				condition = conditionFactory.newCondition();
				addCondition(event, source, condition);
			}

			try
			{
				condition.await();
			}
			catch (InterruptedException e)
			{
				throw new ExecutionInterruptedException(e);
			}
		}
		
		/*
		 * Looks into the internal storage of conditions being waited for and
		 * returns the condition if existing, otherwise null.
		 */
		private Condition findCondition(Class<?> event, ICDIObject source)
		{
			int hash = getHashCode(event, source);
			return _conditions.get(hash);
		}

		/*
		 * Adds the condition to the internal storage of conditions being waited for.
		 */
		private void addCondition(Class<?> event, ICDIObject source, Condition condition)
		{
			int hash = getHashCode(event, source);
			_conditions.put(hash, condition);
		}

		/*
		 * Removes the condition from the internal storage of conditions being waited for.
		 */
		private void removeCondition(Class<?> event, ICDIObject source)
		{
			int hash = getHashCode(event, source);
			_conditions.remove(hash);
		}
		
		/*
		 * Calculates the hash code for an event/source combination; used for the
		 * internal storage of conditions being waited for.
		 */
		private int getHashCode(Class<?> event, ICDIObject source)
		{
			int hash = 5;
			hash = 79 * hash + (event != null ? event.hashCode() : 0);
			hash = 79 * hash + (source != null ? source.hashCode() : 0);
			return hash;
		}
	}

}
